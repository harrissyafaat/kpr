		<div class="sidebarmenu">
				<a class="menuitem" href="index.php?pilih=home"><b>Home</b></a>
				<a class="menuitem submenuheader" href=""><b><b>Master Data</b></a>
					<div class="submenu">
						<ul>
							<li><a href="index.php?pilih=1.1"><b>Master Petugas</b></a></li>
							<li><a href="index.php?pilih=1.2"><b>Master Anggota</b></a></li>
							<!-- <li><a href="index.php?pilih=1.3">Master Tabungan</a></li> -->
						</ul>
					</div>
				<a class="menuitem submenuheader" href="" ><b>Transaksi</b></a>
					<div class="submenu">
						<ul>
							<li><a href="index.php?pilih=2.1"><b>Transaksi</b></a></li>
						</ul>
					</div>
				<a class="menuitem submenuheader" href="" ><b>Laporan</b></a>
					<div class="submenu">
						<ul>
							<li><a href="index.php?pilih=3.1"><b>Data Anggota</b></a></li>
							<li><a href="index.php?pilih=3.2"><b>Data Simpanan</b></a></li>
							<li><a href="index.php?pilih=3.3"><b>Data Pinjaman</b></a></li>
						</ul>
					</div>
				<a class="menuitem submenuheader" href="" ><b>Setting</b></a>
					<div class="submenu">
						<ul>
						<li><a href="index.php?pilih=4.1"><b>Setting Simpanan</b></a></li>
						<li><a href="index.php?pilih=4.2"><b>Setting Pinjaman</b></a></li>
						<li><a href="index.php?pilih=4.3"><b>Setting User</b></a></li>
						</ul>
					</div>
				<a class="menuitem_red" href="login/proses_logout.php"><b>Logout</b></a>
			</div><br />

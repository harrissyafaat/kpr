<div class="row">
  <div class="col-12">
<div class="card mb-3" style="width: 970px; margin-top: 10px; height: 100%;">
  <div class="card-header">
    <i class="fa"></i><h5> Selamat Datang Di Aplikasi Simpan Pinjam Jam'iyah Waqi'ah "Sunan Kalijogo" Kediri.</h5></div>
  <div class="card-body">

	<h4>Visi Koperasi</h4>
	<p align="justify">Visi Jam'iyah Waqi'ah "Sunan Kalijogo" adalah membangun ekonomi ummah. </p><br />
	<h4>Misi Koperasi</h4>
	<p align="justify">Misi Jam'iyah Waqi'ah "Sunan Kalijogo" adalah menerapkan prinsip-prinsip syari'at dalam kegiatan ekonomi, memberdayakan pengusaha kecil dan menengah, serta membentuk ukhuwah islamiyah.</p>
	<br /><br />
	<p align="right">Management</p>
</div>
</div>
</div>
</div>
<link type="text/css" href="jquery/ui.all.css" rel="stylesheet" />
<script type="text/javascript" src="jquery/jquery-1.4.2.js"></script>
<script type="text/javascript" src="jquery/jquery-ui-1.8.4.custom.min.js"></script>
<script type="text/javascript">
		$(function(){
			$('#datepicker').datepicker({
			});
		});
</script>
<div id="datepicker"></div>
